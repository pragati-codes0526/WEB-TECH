
/* ========================================
   HAVEN & HUE - CLIENT LOGIN
======================================== */

// Get HTML elements
const authForm = document.getElementById("authForm");

const formTitle = document.getElementById("formTitle");
const formDescription = document.getElementById("formDescription");

const nameGroup = document.getElementById("nameGroup");
const fullName = document.getElementById("fullName");

const email = document.getElementById("email");
const password = document.getElementById("password");

const confirmPasswordGroup = document.getElementById(
    "confirmPasswordGroup"
);
const confirmPassword = document.getElementById("confirmPassword");

const togglePassword = document.getElementById("togglePassword");
const switchMode = document.getElementById("switchMode");
const switchText = document.getElementById("switchText");

const submitButton = document.getElementById("submitButton");
const formMessage = document.getElementById("formMessage");

// Track whether the form is in signup mode
let isSignupMode = false;


// 1. Switch between Login and Signup
switchMode.addEventListener("click", function () {

    isSignupMode = !isSignupMode;

    // Clear old messages and form values
    formMessage.textContent = "";
    authForm.reset();

    if (isSignupMode) {

        // Show signup fields
        nameGroup.hidden = false;
        confirmPasswordGroup.hidden = false;

        fullName.required = true;
        confirmPassword.required = true;

        // Update headings and button
        formTitle.textContent = "Create your account";

        formDescription.textContent =
            "Join Haven & Hue and make your space feel like home.";

        submitButton.textContent = "Create Account";

        switchText.textContent = "Already have an account?";

        switchMode.textContent = "Sign in";

        // Use signup autocomplete hints
        password.autocomplete = "new-password";

    } else {

        // Hide signup fields
        nameGroup.hidden = true;
        confirmPasswordGroup.hidden = true;

        fullName.required = false;
        confirmPassword.required = false;

        // Update headings and button
        formTitle.textContent = "Sign in to your account";

        formDescription.textContent =
            "Enter your details to continue your journey with us.";

        submitButton.textContent = "Sign In";

        switchText.textContent = "Don't have an account?";

        switchMode.textContent = "Create account";

        // Use login autocomplete hint
        password.autocomplete = "current-password";
    }

    // Reset password visibility
    password.type = "password";
    confirmPassword.type = "password";
    togglePassword.textContent = "Show";
    togglePassword.setAttribute("aria-label", "Show password");
});


// 2. Show or Hide Password
togglePassword.addEventListener("click", function () {

    const isPasswordHidden = password.type === "password";

    password.type = isPasswordHidden ? "text" : "password";

    togglePassword.textContent = isPasswordHidden ? "Hide" : "Show";

    togglePassword.setAttribute(
        "aria-label",
        isPasswordHidden ? "Hide password" : "Show password"
    );
});


// 3. Handle Form Submission
authForm.addEventListener("submit", function (event) {

    // Prevent the browser from reloading the page
    event.preventDefault();

    formMessage.textContent = "";
    formMessage.style.color = "#56664F";

    // Basic signup validation
    if (isSignupMode) {

        if (password.value !== confirmPassword.value) {

            formMessage.textContent =
                "Passwords do not match. Please try again.";

            formMessage.style.color = "#B42318";

            confirmPassword.focus();

            return;
        }

        formMessage.textContent =
            "Your form is valid! Customer account creation is not connected yet.";

    } else {

        formMessage.textContent =
            "Your form is valid! Customer login is not connected yet.";
    }
});
