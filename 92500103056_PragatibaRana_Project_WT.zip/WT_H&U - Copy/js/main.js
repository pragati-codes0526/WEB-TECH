
/* =========================================
   ADMIN PRODUCTS → CUSTOMER SHOP
========================================= */

const productGrid = document.getElementById("productGrid");

if (productGrid) {
    const savedProducts = localStorage.getItem("havenHueProducts");

    // Use the admin catalogue when it exists.
    // Otherwise, keep the existing Shop products.
    if (savedProducts) {
        try {
            const products = JSON.parse(savedProducts);

            if (Array.isArray(products)) {
                productGrid.innerHTML = "";

                products.forEach(function (product) {
                    const category = product.category;
                    const price = Number(product.price);

                    if (
                        !product.id ||
                        !product.name ||
                        !category ||
                        !Number.isFinite(price) ||
                        !product.image
                    ) {
                        return;
                    }

                    const card = document.createElement("div");
                    card.className =
                        "col-12 col-sm-6 col-lg-4 product-item";

                    card.dataset.id = product.id;
                    card.dataset.name = product.name;
                    card.dataset.category = category;
                    card.dataset.price = price;

                    const productCard = document.createElement("div");
                    productCard.className = "product-card";

                    const wishlistButton = document.createElement("button");
                    wishlistButton.className = "wishlist-btn";
                    wishlistButton.type = "button";
                    wishlistButton.dataset.id = product.id;
                    wishlistButton.textContent = "♡";
                    wishlistButton.setAttribute(
                        "aria-label",
                        "Add " + product.name + " to wishlist"
                    );
                    wishlistButton.setAttribute("aria-pressed", "false");

                    const image = document.createElement("img");
                    image.src = product.image;
                    image.alt = product.name;

                    const info = document.createElement("div");
                    info.className = "product-info";

                    const name = document.createElement("h3");
                    name.textContent = product.name;

                    const productPrice = document.createElement("p");
                    productPrice.className = "product-price";
                    productPrice.textContent =
                        "₹" + price.toLocaleString("en-IN");

                    const cartButton = document.createElement("button");
                    cartButton.className = "product-btn add-cart";
                    cartButton.type = "button";
                    cartButton.dataset.id = product.id;
                    cartButton.textContent = "Add to Cart";

                    info.append(name, productPrice, cartButton);
                    productCard.append(
                        wishlistButton,
                        image,
                        info
                    );
                    card.appendChild(productCard);
                    productGrid.appendChild(card);
                });
            }
        } catch (error) {
            console.error("Could not load the admin product catalogue.", error);
        }
    }
}



/* SHOP: SEARCH AND CATEGORY FILTERS */

const productSearch = document.getElementById("productSearch");
const filterButtons = document.querySelectorAll(".filter-btn");
const productItems = document.querySelectorAll(".product-item");
const noProducts = document.getElementById("noProducts");

if (productSearch && filterButtons.length > 0) {
    let selectedCategory = "all";

    function filterProducts() {
        const searchText = productSearch.value.toLowerCase().trim();
        let visibleCount = 0;

        productItems.forEach(function (item) {
            const category = item.dataset.category;
            const productName = item.querySelector("h3").textContent.toLowerCase();

            const matchesCategory =
                selectedCategory === "all" || category === selectedCategory;

            const matchesSearch = productName.includes(searchText);

            if (matchesCategory && matchesSearch) {
                item.hidden = false;
                visibleCount++;
            } else {
                item.hidden = true;
            }
        });

        if (noProducts) {
            noProducts.hidden = visibleCount !== 0;
        }
    }

    filterButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            selectedCategory = button.dataset.category;

            filterButtons.forEach(function (btn) {
                btn.classList.remove("active");
            });

            button.classList.add("active");
            filterProducts();
        });
    });

    productSearch.addEventListener("input", filterProducts);
}


/* =========================
   CART SUCCESS NOTIFICATION
========================= */

let cartToastTimer;

function showCartToast(productName) {
    const toast = document.getElementById("cartToast");
    const message = document.getElementById("cartToastMessage");
    const closeButton = document.getElementById("cartToastClose");

    if (!toast || !message || !closeButton) return;

    message.textContent = productName + " has been added successfully.";

    clearTimeout(cartToastTimer);

    toast.hidden = false;

    requestAnimationFrame(function () {
        toast.classList.add("show");
    });

    closeButton.onclick = function () {
        hideCartToast();
    };

    cartToastTimer = setTimeout(function () {
        hideCartToast();
    }, 3000);
}

function hideCartToast() {
    const toast = document.getElementById("cartToast");

    if (!toast) return;

    toast.classList.remove("show");

    setTimeout(function () {
        if (!toast.classList.contains("show")) {
            toast.hidden = true;
        }
    }, 300);
}


// SHOPPING CART: ADD PRODUCTS AND UPDATE CART COUNT

function getCart() {
    return JSON.parse(localStorage.getItem("havenHueCart")) || [];
}

function saveCart(cart) {
    localStorage.setItem("havenHueCart", JSON.stringify(cart));
}

function updateCartCount() {
    const cart = getCart();

    const totalItems = cart.reduce(function (total, item) {
        return total + item.quantity;
    }, 0);

    document.querySelectorAll(".cart-count").forEach(function (element) {
        element.textContent = totalItems;
    });
}

document.querySelectorAll(".add-cart").forEach(function (button) {
    button.addEventListener("click", function () {
        const product = button.closest(".product-item");

        if (!product) return;

        const id = product.dataset.id;
        const name = product.dataset.name;
        const price = Number(product.dataset.price);
        const image = product.querySelector("img").getAttribute("src");

        if (!id || !name || !Number.isFinite(price)) {
            alert("Product information is missing.");
            return;
        }

        const cart = getCart();
        const existingItem = cart.find(function (item) {
            return item.id === id;
        });

        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({
                id: id,
                name: name,
                price: price,
                image: image,
                quantity: 1
            });
        }

        saveCart(cart);
        updateCartCount();

        // Show the success notification instead of an alert.
        showCartToast(name);
    });
});

updateCartCount();


// SHOPPING CART: DISPLAY PRODUCTS AND MANAGE QUANTITIES

const cartItemsContainer = document.getElementById("cartItems");
const cartSummary = document.getElementById("cartSummary");
const emptyCart = document.getElementById("emptyCart");

function renderCart() {
    if (!cartItemsContainer) return;

    const cart = getCart();
    cartItemsContainer.innerHTML = "";

    if (cart.length === 0) {
        cartSummary.hidden = true;
        emptyCart.hidden = false;
        updateCartCount();
        return;
    }

    cartSummary.hidden = false;
    emptyCart.hidden = true;

    let total = 0;

    cart.forEach(function (item) {
        const subtotal = item.price * item.quantity;
        total += subtotal;

        const row = document.createElement("div");
        row.className = "cart-item";

        const image = document.createElement("img");
        image.src = item.image;
        image.alt = item.name;

        const details = document.createElement("div");
        details.className = "cart-item-details";

        const name = document.createElement("h3");
        name.textContent = item.name;

        const price = document.createElement("p");
        price.textContent = "Price: ₹" + item.price.toLocaleString("en-IN");

        const quantity = document.createElement("p");
        quantity.textContent = "Quantity: " + item.quantity;

        const controls = document.createElement("div");
        controls.className = "cart-controls";

        const decrease = document.createElement("button");
        decrease.className = "product-btn";
        decrease.textContent = "−";
        decrease.setAttribute("aria-label", "Decrease quantity");
        decrease.addEventListener("click", function () {
            changeQuantity(item.id, -1);
        });

        const increase = document.createElement("button");
        increase.className = "product-btn";
        increase.textContent = "+";
        increase.setAttribute("aria-label", "Increase quantity");
        increase.addEventListener("click", function () {
            changeQuantity(item.id, 1);
        });

        const remove = document.createElement("button");
        remove.className = "remove-cart-btn";
        remove.textContent = "Remove";
        remove.addEventListener("click", function () {
            removeFromCart(item.id);
        });

        controls.append(decrease, increase, remove);
        details.append(name, price, quantity, controls);
        row.append(image, details);
        cartItemsContainer.appendChild(row);
    });

    document.getElementById("cartTotal").textContent =
        "₹" + total.toLocaleString("en-IN");

    updateCartCount();
}

function changeQuantity(id, change) {
    const cart = getCart();
    const item = cart.find(function (product) {
        return product.id === id;
    });

    if (!item) return;

    item.quantity += change;

    const updatedCart = cart.filter(function (product) {
        return product.quantity > 0;
    });

    saveCart(updatedCart);
    renderCart();
}

function removeFromCart(id) {
    const updatedCart = getCart().filter(function (item) {
        return item.id !== id;
    });

    saveCart(updatedCart);
    renderCart();
}

const clearCartButton = document.getElementById("clearCart");

if (clearCartButton) {
    clearCartButton.addEventListener("click", function () {
        saveCart([]);
        renderCart();
    });
}


// CHECKOUT BUTTON: OPEN CHECKOUT PAGE

const checkoutButton = document.getElementById("checkoutBtn");

if (checkoutButton) {
    checkoutButton.addEventListener("click", function () {
        const cart = getCart();

        if (cart.length === 0) {
            alert("Your cart is empty!");
            return;
        }

        window.location.href = "checkout.html";
    });
}

renderCart();


// CONTACT FORM VALIDATION

const contactForm = document.getElementById("contactForm");
const contactFeedback = document.getElementById("contactFeedback");

if (contactForm && contactFeedback) {
    const nameInput = document.getElementById("contactName");
    const emailInput = document.getElementById("contactEmail");
    const subjectInput = document.getElementById("contactSubject");
    const messageInput = document.getElementById("contactMessage");

    const inputs = [
        nameInput,
        emailInput,
        subjectInput,
        messageInput
    ];

    contactForm.addEventListener("submit", function (event) {
        event.preventDefault();

        let isValid = true;

        inputs.forEach(function (input) {
            if (!input.checkValidity()) {
                input.classList.add("is-invalid");
                isValid = false;
            } else {
                input.classList.remove("is-invalid");
            }
        });

        contactFeedback.hidden = false;

        if (!isValid) {
            contactFeedback.textContent =
                "Please correct the highlighted fields.";
            contactFeedback.style.backgroundColor = "#F8D7DA";
            contactFeedback.style.color = "#842029";
            return;
        }

        contactFeedback.textContent =
            "Thanks for reaching out! Your form is valid. Messages are not sent in this demo yet.";
        contactFeedback.style.backgroundColor = "#D1E7DD";
        contactFeedback.style.color = "#0F5132";

        contactForm.reset();

        inputs.forEach(function (input) {
            input.classList.remove("is-invalid");
        });
    });

    inputs.forEach(function (input) {
        input.addEventListener("input", function () {
            if (input.checkValidity()) {
                input.classList.remove("is-invalid");
            }
        });
    });
}


// CHECKOUT: DISPLAY ORDER SUMMARY

const checkoutItems = document.getElementById("checkoutItems");
const checkoutTotal = document.getElementById("checkoutTotal");

if (checkoutItems && checkoutTotal) {
    function renderCheckoutSummary() {
        const cart = getCart();

        checkoutItems.innerHTML = "";

        if (cart.length === 0) {
            checkoutItems.innerHTML = `
                <p>Your cart is empty.</p>
                <a href="shop.html">Continue Shopping</a>
            `;

            checkoutTotal.textContent = "₹0";
            return;
        }

        let total = 0;

        cart.forEach(function (item) {
            const quantity = Number(item.quantity) || 0;
            const price = Number(item.price) || 0;
            const subtotal = price * quantity;

            total += subtotal;

            const itemRow = document.createElement("div");
            itemRow.className = "checkout-item";

            const itemName = document.createElement("span");
            itemName.textContent = `${item.name} × ${quantity}`;

            const itemPrice = document.createElement("strong");
            itemPrice.textContent = `₹${subtotal.toLocaleString("en-IN")}`;

            itemRow.appendChild(itemName);
            itemRow.appendChild(itemPrice);

            checkoutItems.appendChild(itemRow);
        });

        checkoutTotal.textContent =
            `₹${total.toLocaleString("en-IN")}`;
    }

    renderCheckoutSummary();
}


// CHECKOUT: FORM VALIDATION AND DEMO ORDER

const checkoutForm = document.getElementById("checkoutForm");
const checkoutFeedback = document.getElementById("checkoutFeedback");

if (checkoutForm && checkoutFeedback) {
    const checkoutInputs = [
        document.getElementById("fullName"),
        document.getElementById("checkoutEmail"),
        document.getElementById("checkoutPhone"),
        document.getElementById("checkoutAddress"),
        document.getElementById("checkoutCity"),
        document.getElementById("checkoutPincode"),
        document.getElementById("checkoutPayment")
    ];

    checkoutForm.addEventListener("submit", function (event) {
        event.preventDefault();

        let isValid = true;

        checkoutInputs.forEach(function (input) {
            if (!input.checkValidity()) {
                input.classList.add("is-invalid");
                isValid = false;
            } else {
                input.classList.remove("is-invalid");
            }
        });

        checkoutFeedback.hidden = false;

        if (!isValid) {
            checkoutFeedback.textContent =
                "Please fill in all fields correctly.";
            checkoutFeedback.style.backgroundColor = "#F8D7DA";
            checkoutFeedback.style.color = "#842029";
            return;
        }

        const cart = getCart();

        if (cart.length === 0) {
            checkoutFeedback.textContent =
                "Your cart is empty. Please add products before placing an order.";
            checkoutFeedback.style.backgroundColor = "#F8D7DA";
            checkoutFeedback.style.color = "#842029";
            return;
        }

      
checkoutFeedback.textContent =
    "Demo order placed successfully! Your order is now saved.";
checkoutFeedback.style.backgroundColor = "#D1E7DD";
checkoutFeedback.style.color = "#0F5132";

// Calculate the order total
const orderTotal = cart.reduce(function (sum, item) {
    return sum + Number(item.price) * Number(item.quantity);
}, 0);

// Create a unique demo order
const newOrder = {
    id: "HH" + Date.now(),
    customer: document.getElementById("fullName").value.trim(),
    email: document.getElementById("checkoutEmail").value.trim(),
    phone: document.getElementById("checkoutPhone").value.trim(),
    address: document.getElementById("checkoutAddress").value.trim(),
    city: document.getElementById("checkoutCity").value.trim(),
    pincode: document.getElementById("checkoutPincode").value.trim(),
    payment: document.getElementById("checkoutPayment").value,
    date: new Date().toISOString().slice(0, 10),
    items: cart.reduce(function (sum, item) {
        return sum + Number(item.quantity);
    }, 0),
    products: cart.map(function (item) {
        return {
            id: item.id,
            name: item.name,
            price: Number(item.price),
            quantity: Number(item.quantity),
            image: item.image
        };
    }),
    total: orderTotal,
    status: "Pending"
};

// Preserve existing orders and add the new order
const savedOrders = localStorage.getItem("havenHueOrders");
let allOrders = [];

try {
    const parsedOrders = savedOrders ? JSON.parse(savedOrders) : [];
    allOrders = Array.isArray(parsedOrders) ? parsedOrders : [];
} catch (error) {
    console.error("Could not read existing orders.", error);
    checkoutFeedback.textContent =
        "Could not load existing orders. Please check the browser console.";
    checkoutFeedback.style.backgroundColor = "#F8D7DA";
    checkoutFeedback.style.color = "#842029";
    return;
}

allOrders.push(newOrder);
localStorage.setItem("havenHueOrders", JSON.stringify(allOrders));

// Clear the cart only after saving the order
saveCart([]);
updateCartCount();

checkoutForm.reset();


        checkoutForm.reset();

        checkoutInputs.forEach(function (input) {
            input.classList.remove("is-invalid");
        });

        if (checkoutItems && checkoutTotal) {
            checkoutItems.innerHTML =
                "<p>Your demo order is complete. Thank you for shopping with Haven & Hue!</p>";
            checkoutTotal.textContent = "₹0";
        }
    });

    checkoutInputs.forEach(function (input) {
        input.addEventListener("input", function () {
            if (input.checkValidity()) {
                input.classList.remove("is-invalid");
            }
        });

        input.addEventListener("change", function () {
            if (input.checkValidity()) {
                input.classList.remove("is-invalid");
            }
        });
    });
}


/* PRODUCT DETAILS PAGE CONNECTION */

const shopProducts = document.querySelectorAll(".product-item");

shopProducts.forEach(function (product) {
    const productImage = product.querySelector("img");

    if (productImage) {
        productImage.style.cursor = "pointer";

        productImage.addEventListener("click", function () {
            const productId = product.dataset.id;

            window.location.href =
                "product.html?id=" + encodeURIComponent(productId);
        });
    }
});


/* HAVEN & HUE: DYNAMIC PRODUCT DETAILS */

const detailImage = document.getElementById("detailImage");

if (detailImage) {
    const products = {
        vase1: {
            name: "Ceramic Vase 1",
            price: 799,
            image: "CERAMIC_VASE_1.jpg",
            category: "Decorative Vase",
            description: "Add an elegant touch to your home with this ceramic vase. Perfect for shelves, tables, and living room decor.",
            rating: "4.5",
            reviews: [
                { name: "Aarav", stars: 5, text: "Beautiful design and lovely home decor." },
                { name: "Priya", stars: 4, text: "Looks elegant on my living room table." }
            ]
        },
        vase2: {
            name: "Ceramic Vase 2",
            price: 899,
            image: "CERAMIC_VASE_2.jpg",
            category: "Decorative Vase",
            description: "A stylish ceramic vase designed to complement modern interiors and create a warm, welcoming space.",
            rating: "4.6",
            reviews: [
                { name: "Riya", stars: 5, text: "Lovely vase with a beautiful look." },
                { name: "Neha", stars: 4, text: "A nice addition to my home decor." }
            ]
        },
        vase3: {
            name: "Ceramic Vase 3",
            price: 999,
            image: "CERAMIC_VASE_3.jpg",
            category: "Decorative Vase",
            description: "Give your space a refined look with this decorative ceramic vase, ideal for tabletops and display shelves.",
            rating: "4.4",
            reviews: [
                { name: "Anaya", stars: 5, text: "Looks great with my other decor." },
                { name: "Kavya", stars: 4, text: "Simple and elegant." }
            ]
        },
        vase4: {
            name: "Ceramic Vase 4",
            price: 1099,
            image: "CERAMIC_VASE_4.jpg",
            category: "Decorative Vase",
            description: "A statement ceramic vase for adding character and style to your favourite corner.",
            rating: "4.7",
            reviews: [
                { name: "Meera", stars: 5, text: "A lovely decorative piece." },
                { name: "Isha", stars: 4, text: "Fits beautifully with neutral decor." }
            ]
        },

        table1: {
            name: "Modern Table 1",
            price: 4999,
            image: "Table_1.jpg",
            category: "Modern Table",
            description: "A modern table designed to bring functionality and timeless style to your living space.",
            rating: "4.5",
            reviews: [
                { name: "Dev", stars: 5, text: "A stylish choice for my home." },
                { name: "Mira", stars: 4, text: "Looks good in the living room." }
            ]
        },
        table2: {
            name: "Modern Table 2",
            price: 5499,
            image: "Table_2.jpg",
            category: "Modern Table",
            description: "Refresh your interior with this versatile modern table, designed for everyday use.",
            rating: "4.4",
            reviews: [
                { name: "Aditi", stars: 5, text: "Beautiful design." },
                { name: "Jay", stars: 4, text: "Works well in my space." }
            ]
        },
        table3: {
            name: "Modern Table 3",
            price: 5999,
            image: "Table_3.jpg",
            category: "Modern Table",
            description: "A contemporary table that combines practical use with a clean, modern appearance.",
            rating: "4.6",
            reviews: [
                { name: "Diya", stars: 5, text: "Love the modern style." },
                { name: "Kunal", stars: 4, text: "A nice furniture piece." }
            ]
        },
        table4: {
            name: "Modern Table 4",
            price: 6499,
            image: "Table_4.jpg",
            category: "Modern Table",
            description: "Make your home feel complete with this contemporary table for everyday living.",
            rating: "4.5",
            reviews: [
                { name: "Tara", stars: 5, text: "Looks elegant." },
                { name: "Rohan", stars: 4, text: "Good style for my home." }
            ]
        },

        lamp1: {
            name: "Table Lamp 1",
            price: 1499,
            image: "TableLamp_1.jpg",
            category: "Table Lamp",
            description: "Create a warm atmosphere with this decorative table lamp, perfect for bedside tables and reading corners.",
            rating: "4.5",
            reviews: [
                { name: "Nisha", stars: 5, text: "Gives my room a cosy look." },
                { name: "Arjun", stars: 4, text: "A lovely lamp for the bedroom." }
            ]
        },
        lamp2: {
            name: "Table Lamp 2",
            price: 1699,
            image: "TableLamp_2.jpg",
            category: "Table Lamp",
            description: "A stylish table lamp that adds warmth and character to your favourite corner.",
            rating: "4.6",
            reviews: [
                { name: "Pooja", stars: 5, text: "Looks beautiful on my side table." },
                { name: "Aman", stars: 4, text: "Nice decorative lighting." }
            ]
        },
        lamp3: {
            name: "Table Lamp 3",
            price: 1799,
            image: "TableLamp_3.jpg",
            category: "Table Lamp",
            description: "Bring soft ambience and modern style to your room with this decorative table lamp.",
            rating: "4.4",
            reviews: [
                { name: "Ira", stars: 5, text: "Perfect for my room." },
                { name: "Manav", stars: 4, text: "Simple and attractive." }
            ]
        },
        lamp4: {
            name: "Table Lamp 4",
            price: 1999,
            image: "TableLamp_4.jpg",
            category: "Table Lamp",
            description: "Add a refined lighting accent to your bedside, desk, or living room.",
            rating: "4.7",
            reviews: [
                { name: "Sana", stars: 5, text: "Beautiful lighting and design." },
                { name: "Nikhil", stars: 4, text: "Looks great on my desk." }
            ]
        },
        lamp5: {
            name: "Table Lamp 5",
            price: 2199,
            image: "TableLamp_5.jpg",
            category: "Table Lamp",
            description: "Complete your interior with a decorative table lamp designed for a welcoming atmosphere.",
            rating: "4.5",
            reviews: [
                { name: "Anvi", stars: 5, text: "Lovely addition to my room." },
                { name: "Rahul", stars: 4, text: "A stylish lamp." }
            ]
        },

        clock1: {
            name: "Elegant Wall Clock 1",
            price: 1199,
            image: "WallClock_1.jpg",
            category: "Wall Clock",
            description: "Keep time in style with a decorative wall clock for your living room, bedroom, or hallway.",
            rating: "4.5",
            reviews: [
                { name: "Khushi", stars: 5, text: "Looks lovely on the wall." },
                { name: "Vivek", stars: 4, text: "A nice finishing touch." }
            ]
        },
        clock2: {
            name: "Elegant Wall Clock 2",
            price: 1399,
            image: "WallClock_2.jpg",
            category: "Wall Clock",
            description: "A stylish wall clock that combines everyday usefulness with decorative appeal.",
            rating: "4.4",
            reviews: [
                { name: "Jiya", stars: 5, text: "Beautiful wall decor." },
                { name: "Karan", stars: 4, text: "Fits my room nicely." }
            ]
        },
        clock3: {
            name: "Elegant Wall Clock 3",
            price: 1599,
            image: "WallClock_3.jpg",
            category: "Wall Clock",
            description: "Enhance your walls with this elegant clock, ideal for modern home interiors.",
            rating: "4.6",
            reviews: [
                { name: "Mahi", stars: 5, text: "A great decorative piece." },
                { name: "Yash", stars: 4, text: "Looks good in my living room." }
            ]
        },
        clock4: {
            name: "Elegant Wall Clock 4",
            price: 1799,
            image: "WallClock_4.jpg",
            category: "Wall Clock",
            description: "Give your interior a polished look with this decorative wall clock.",
            rating: "4.5",
            reviews: [
                { name: "Aarohi", stars: 5, text: "Really like the design." },
                { name: "Dhruv", stars: 4, text: "Nice wall accent." }
            ]
        },
        clock5: {
            name: "Elegant Wall Clock 5",
            price: 1999,
            image: "WallClock_5.jpg",
            category: "Wall Clock",
            description: "Add character to your home with a wall clock made to complement your decor.",
            rating: "4.7",
            reviews: [
                { name: "Siya", stars: 5, text: "Looks elegant and modern." },
                { name: "Om", stars: 4, text: "A good decorative choice." }
            ]
        },

        painting1: {
            name: "Wall Painting 1",
            price: 1999,
            image: "WallPainting_1.jpg",
            category: "Wall Art",
            description: "Bring personality to your walls with decorative artwork for your living room or bedroom.",
            rating: "4.5",
            reviews: [
                { name: "Avni", stars: 5, text: "Makes the wall look beautiful." },
                { name: "Parth", stars: 4, text: "Nice addition to my decor." }
            ]
        },
        painting2: {
            name: "Wall Painting 2",
            price: 2199,
            image: "WallPainting_2.jpg",
            category: "Wall Art",
            description: "Refresh your room with wall art designed to complement your favourite interior style.",
            rating: "4.6",
            reviews: [
                { name: "Esha", stars: 5, text: "Lovely artwork for the living room." },
                { name: "Harsh", stars: 4, text: "Looks great on the wall." }
            ]
        },
        painting3: {
            name: "Wall Painting 3",
            price: 2399,
            image: "WallPainting_3.jpg",
            category: "Wall Art",
            description: "Make a statement with decorative wall art that adds interest and character to your space.",
            rating: "4.4",
            reviews: [
                { name: "Myra", stars: 5, text: "Beautiful decorative artwork." },
                { name: "Krish", stars: 4, text: "Complements my room." }
            ]
        },
        painting4: {
            name: "Wall Painting 4",
            price: 2599,
            image: "WallPainting_4.jpg",
            category: "Wall Art",
            description: "Give your walls a fresh look with this decorative artwork for a welcoming home.",
            rating: "4.7",
            reviews: [
                { name: "Aisha", stars: 5, text: "Exactly the style I wanted." },
                { name: "Reyansh", stars: 4, text: "Looks lovely in my space." }
            ]
        }
    };

    const params = new URLSearchParams(window.location.search);
    const selectedId = params.get("id");
    const product = products[selectedId];

    if (product) {
        document.getElementById("detailName").textContent = product.name;
        document.getElementById("detailPrice").textContent =
            "₹" + product.price.toLocaleString("en-IN");

        detailImage.src = "../images/" + product.image;
        detailImage.alt = product.name;

        document.getElementById("detailDescription").textContent =
            product.description;

        document.title = product.name + " | Haven & Hue";

        // Add the demo rating and review section.
        let reviewSection = document.getElementById("detailReviews");

        if (!reviewSection) {
            reviewSection = document.createElement("section");
            reviewSection.id = "detailReviews";
            reviewSection.className = "product-reviews";
            document.querySelector(".product-details-info")
                .appendChild(reviewSection);
        }

        reviewSection.innerHTML = `
            <hr>
            <h3>Customer Reviews</h3>
            <p><strong>★ ${product.rating} out of 5</strong></p>
            <p class="text-muted">
                Sample reviews for project demonstration — not verified customer feedback.
            </p>
            ${product.reviews.map(function (review) {
                return `
                    <div class="review-item">
                        <strong>${review.name}</strong>
                        <p class="review-stars">${"★".repeat(review.stars)}${"☆".repeat(5 - review.stars)}</p>
                        <p>${review.text}</p>
                    </div>
                `;
            }).join("")}
        `;

        // Quantity selector.
        const quantityInput = document.getElementById("detailQuantity");
        const decreaseButton = document.getElementById("decreaseDetailQty");
        const increaseButton = document.getElementById("increaseDetailQty");

        if (quantityInput && decreaseButton && increaseButton) {
            decreaseButton.addEventListener("click", function () {
                quantityInput.value = Math.max(
                    1, Number(quantityInput.value) - 1
                );
            });

            increaseButton.addEventListener("click", function () {
                quantityInput.value = Math.min(
                    99, Number(quantityInput.value) + 1
                );
            });
        }

        // Add selected product and quantity to the existing cart.
        const detailAddButton = document.getElementById("detailAddToCart");

        if (detailAddButton) {
            detailAddButton.addEventListener("click", function () {
                const cart = getCart();
                const quantity = Math.max(
                    1,
                    Math.min(99, Number(quantityInput?.value) || 1)
                );

                const existingItem = cart.find(function (item) {
                    return item.id === selectedId;
                });

                if (existingItem) {
                    existingItem.quantity += quantity;
                } else {
                    cart.push({
                        id: selectedId,
                        name: product.name,
                        price: product.price,
                        image: "../images/" + product.image,
                        quantity: quantity
                    });
                }

                saveCart(cart);
                updateCartCount();

                // Show the same success notification on the details page.
                showCartToast(product.name);
            });
        }
    } else {
        document.getElementById("detailName").textContent =
            "Product not found";

        document.getElementById("detailDescription").textContent =
            "Please return to the Shop page and select a product.";

        document.getElementById("detailPrice").textContent = "";
        detailImage.hidden = true;
    }
}

